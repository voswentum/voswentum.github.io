import { useState, useEffect, useCallback } from 'react';
import { questions, results, BeastResult } from './data';

type Screen = 'start' | 'question' | 'result';

function Confetti() {
  const [particles, setParticles] = useState<Array<{id: number; x: number; delay: number; color: string; size: number}>>([]);
  
  useEffect(() => {
    const colors = ['#ef4444', '#f97316', '#eab308', '#22c55e', '#3b82f6', '#a855f7', '#ec4899'];
    const newParticles = Array.from({length: 30}, (_, i) => ({
      id: i,
      x: Math.random() * 100,
      delay: Math.random() * 2,
      color: colors[Math.floor(Math.random() * colors.length)],
      size: Math.random() * 8 + 4,
    }));
    setParticles(newParticles);
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      {particles.map(p => (
        <div
          key={p.id}
          className="absolute animate-confetti-fall"
          style={{
            left: `${p.x}%`,
            top: '-20px',
            width: `${p.size}px`,
            height: `${p.size}px`,
            backgroundColor: p.color,
            borderRadius: Math.random() > 0.5 ? '50%' : '2px',
            animationDelay: `${p.delay}s`,
            animationDuration: `${2 + Math.random() * 2}s`,
          }}
        />
      ))}
    </div>
  );
}

function App() {
  const [screen, setScreen] = useState<Screen>('start');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [scores, setScores] = useState<Record<string, number>>({
    belka: 0,
    lisa: 0,
    lev: 0,
    koroleva: 0,
    blitz: 0,
    labubu: 0,
  });
  const [result, setResult] = useState<BeastResult | null>(null);
  const [fadeIn, setFadeIn] = useState(true);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showConfetti, setShowConfetti] = useState(false);

  const handleAnswer = useCallback((answerIndex: number) => {
    setSelectedAnswer(answerIndex);
    const answer = questions[currentQuestion].answers[answerIndex];
    
    const newScores = { ...scores };
    Object.entries(answer.scores).forEach(([key, value]) => {
      newScores[key] = (newScores[key] || 0) + value;
    });
    setScores(newScores);

    setTimeout(() => {
      setFadeIn(false);
      setTimeout(() => {
        if (currentQuestion < questions.length - 1) {
          setCurrentQuestion(prev => prev + 1);
          setSelectedAnswer(null);
          setFadeIn(true);
        } else {
          let maxScore = 0;
          let winnerId = 'belka';
          Object.entries(newScores).forEach(([id, score]) => {
            if (score > maxScore) {
              maxScore = score;
              winnerId = id;
            }
          });
          const beast = results.find(r => r.id === winnerId);
          setResult(beast || results[0]);
          setScreen('result');
          setSelectedAnswer(null);
          setFadeIn(true);
          setShowConfetti(true);
          setTimeout(() => setShowConfetti(false), 4000);
        }
      }, 300);
    }, 600);
  }, [currentQuestion, scores]);

  const startTest = () => {
    setFadeIn(false);
    setTimeout(() => {
      setScreen('question');
      setFadeIn(true);
    }, 300);
  };

  const restartTest = () => {
    setFadeIn(false);
    setTimeout(() => {
      setScreen('start');
      setCurrentQuestion(0);
      setScores({ belka: 0, lisa: 0, lev: 0, koroleva: 0, blitz: 0, labubu: 0 });
      setResult(null);
      setSelectedAnswer(null);
      setFadeIn(true);
    }, 300);
  };

  useEffect(() => {
    setFadeIn(true);
  }, []);

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-white flex flex-col items-center justify-center relative overflow-hidden">
      {/* Confetti */}
      {showConfetti && <Confetti />}
      
      {/* Background effects */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-red-500/8 rounded-full blur-3xl animate-pulse" style={{animationDelay: '1s'}}></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-red-900/5 rounded-full blur-3xl"></div>
        {/* Grid pattern */}
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: 'linear-gradient(rgba(239,68,68,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(239,68,68,0.3) 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }}></div>
      </div>

      {/* Content */}
      <div className={`relative z-10 w-full max-w-lg mx-auto px-4 py-8 transition-all duration-300 ${fadeIn ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
        
        {/* START SCREEN */}
        {screen === 'start' && (
          <div className="text-center space-y-8">
            <div className="relative inline-block">
              <div className="text-7xl md:text-8xl animate-float">🐾</div>
              <div className="absolute inset-0 bg-red-500/20 rounded-full blur-xl animate-pulse"></div>
            </div>
            <h1 className="text-3xl md:text-5xl font-black bg-gradient-to-r from-red-500 via-red-400 to-red-600 bg-clip-text text-transparent leading-tight">
              ЧТО ТЫ ЗА ЗВЕРЬ<br/>ТАКОЙ?
            </h1>
            <p className="text-gray-400 text-lg max-w-sm mx-auto leading-relaxed">
              5 вопросов, которые раскроют твою истинную звериную сущность. 
              Готов(а) узнать правду? 😈
            </p>
            <button
              onClick={startTest}
              className="group relative px-8 py-4 bg-red-600 hover:bg-red-500 text-white font-bold text-xl rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-[0_0_30px_rgba(239,68,68,0.5)] active:scale-95"
            >
              <span className="relative z-10">УЗНАТЬ СЕБЯ 🐾</span>
              <div className="absolute inset-0 rounded-2xl bg-red-600 blur-lg opacity-50 group-hover:opacity-75 transition-opacity"></div>
            </button>
            <div className="flex items-center justify-center gap-4 text-gray-600 text-sm">
              <span>🕐 2 минуты</span>
              <span>•</span>
              <span>😂 100% мемы</span>
              <span>•</span>
              <span>🐾 6 зверей</span>
            </div>
          </div>
        )}

        {/* QUESTION SCREEN */}
        {screen === 'question' && (
          <div className="space-y-6">
            {/* Progress bar */}
            <div className="flex items-center gap-3">
              <div className="flex-1 h-2 bg-gray-800 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-red-600 to-red-400 rounded-full transition-all duration-500 ease-out"
                  style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
                ></div>
              </div>
              <span className="text-red-400 font-bold text-sm whitespace-nowrap">{currentQuestion + 1}/{questions.length}</span>
            </div>

            {/* Question */}
            <div className="text-center space-y-3 py-2">
              <span className="text-5xl block">{questions[currentQuestion].emoji}</span>
              <h2 className="text-xl md:text-2xl font-bold text-white leading-snug">
                {questions[currentQuestion].question}
              </h2>
            </div>

            {/* Answers */}
            <div className="space-y-3">
              {questions[currentQuestion].answers.map((answer, index) => (
                <button
                  key={index}
                  onClick={() => selectedAnswer === null && handleAnswer(index)}
                  disabled={selectedAnswer !== null}
                  className={`w-full text-left p-4 rounded-xl border transition-all duration-300 ${
                    selectedAnswer === index
                      ? 'border-red-500 bg-red-500/20 shadow-[0_0_20px_rgba(239,68,68,0.3)] scale-[1.02]'
                      : selectedAnswer !== null
                      ? 'border-gray-800 bg-gray-900/50 opacity-40 scale-[0.98]'
                      : 'border-gray-700/50 bg-gray-900/80 hover:border-red-500/50 hover:bg-gray-800/80 hover:shadow-[0_0_15px_rgba(239,68,68,0.15)] active:scale-[0.98]'
                  }`}
                  style={{ animationDelay: `${index * 0.05}s` }}
                >
                  <div className="flex items-start gap-3">
                    <span className="text-2xl flex-shrink-0 mt-0.5">{answer.emoji}</span>
                    <span className="text-gray-200 text-sm md:text-base leading-snug">{answer.text}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* RESULT SCREEN */}
        {screen === 'result' && result && (
          <div className="text-center space-y-6">
            <div className="text-sm text-red-400 font-bold uppercase tracking-wider animate-pulse">
              ✨ Твой результат ✨
            </div>
            
            {/* Beast image */}
            <div className="relative mx-auto w-60 h-60 md:w-72 md:h-72">
              <div className="absolute inset-0 bg-red-600/20 rounded-full blur-2xl animate-pulse"></div>
              <div className="absolute inset-2 bg-red-500/10 rounded-3xl animate-glow"></div>
              <img
                src={result.image}
                alt={result.name}
                className="relative w-full h-full object-cover rounded-3xl border-2 border-red-500/50 shadow-[0_0_40px_rgba(239,68,68,0.3)]"
              />
            </div>

            {/* Beast name */}
            <div className="space-y-2">
              <h2 className="text-2xl md:text-3xl font-black bg-gradient-to-r from-red-500 via-yellow-400 to-red-500 bg-clip-text text-transparent leading-tight">
                {result.name}
              </h2>
              <p className="text-red-400/80 text-sm font-medium">{result.subtitle}</p>
            </div>

            {/* Description */}
            <div className="bg-gray-900/80 border border-red-500/20 rounded-2xl p-5 text-left backdrop-blur-sm">
              <p className="text-gray-300 text-sm md:text-base leading-relaxed">
                {result.description}
              </p>
            </div>

            {/* Share button */}
            <button
              onClick={() => {
                if (navigator.share) {
                  navigator.share({
                    title: 'Что ты за зверь такой?',
                    text: result.shareText,
                  });
                } else {
                  navigator.clipboard.writeText(result.shareText + '\n\nПройди тест и узнай кто ты! 🐾');
                  alert('Скопировано в буфер обмена! Делись с друзьями 😎');
                }
              }}
              className="w-full px-6 py-4 bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white font-bold text-lg rounded-2xl transition-all duration-300 hover:scale-[1.02] hover:shadow-[0_0_30px_rgba(239,68,68,0.4)] active:scale-95"
            >
              📲 Поделиться результатом
            </button>

            {/* Restart */}
            <button
              onClick={restartTest}
              className="text-gray-500 hover:text-red-400 text-sm underline underline-offset-4 transition-colors duration-200"
            >
              Пройти ещё раз 🔄
            </button>
          </div>
        )}
      </div>

      {/* Footer */}
      <div className="fixed bottom-3 left-0 right-0 text-center z-20">
        <p className="text-gray-700 text-[10px] md:text-xs tracking-wide">
          Давыдова Анна — упаковка для экспертов
        </p>
      </div>
    </div>
  );
}

export default App;
